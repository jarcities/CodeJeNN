#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="${1:-${SCRIPT_DIR}/detonationFoam}"
REPO="https://github.com/JieSun-pku/detonationFoam.git"

SRC="${SCRIPT_DIR}/applications/solvers"
DEST_SOL="${DEST}/applications/solvers"

if [ -d "${DEST}/.git" ]; then
    echo "INFO: ${DEST} already exists — skipping clone."
else
    echo "cloning ${REPO} into ${DEST} ..."
    git clone "${REPO}" "${DEST}"
fi

echo "refractoring detonationFoam_V2.0 ..."

cp "${SRC}/detonationFoam_V2.0/Make/options" \
   "${DEST_SOL}/detonationFoam_V2.0/Make/options"

cp "${SRC}/detonationFoam_V2.0/detonationFoam_V2.0.C" \
   "${DEST_SOL}/detonationFoam_V2.0/detonationFoam_V2.0.C"

cp "${SRC}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/solverTypeNS_mixtureAverage.H" \
   "${DEST_SOL}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/solverTypeNS_mixtureAverage.H"

cp "${SRC}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/rhoYEqn_NS_mixtureAverage.H" \
   "${DEST_SOL}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/rhoYEqn_NS_mixtureAverage.H"

cp "${SRC}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/createDiffFields.H" \
   "${DEST_SOL}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/createDiffFields.H"

cp "${SRC}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/createMuFields.H" \
   "${DEST_SOL}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/createMuFields.H"

cp "${SRC}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/readChemistryProperties.H" \
   "${DEST_SOL}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/readChemistryProperties.H"

cp "${SRC}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/updateTransProperties.H" \
   "${DEST_SOL}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/updateTransProperties.H"

echo "adding NN interface headers ..."
TRANSPORT_DEST="${DEST_SOL}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport"

for f in \
    codeJeNN_diffusion.H \
    nn_diffusion_interface.H \
    nn_mu_interface.H \
    model.hpp \
do
    cp "${SRC}/detonationFoam_V2.0/solverTypeNS_mixtureAverage/transport/${f}" \
       "${TRANSPORT_DEST}/${f}"
done

echo "adding utility applications ..."
for util in checkMuNNError checkNNPrediction generateData; do
    cp -r "${SRC}/${util}" "${DEST_SOL}/"
done

cp "${SRC}/Allmake" "${DEST_SOL}/Allmake"
chmod +x "${DEST_SOL}/Allmake"

echo ""
echo "codejenn modifications applied to: ${DEST}"
echo ""
echo "to build (OpenFOAM environment must be sourced and compiled!!!):"
echo "   cd ${DEST_SOL} && ./Allmake"
echo ""
echo "to build only the main solver via the upstream Allwmake:"
echo "   cd ${DEST_SOL}/detonationFoam_V2.0 && ./Allwmake"
echo ""
echo "to undo all modifications and restore the clean clone:"
echo "   ./remove_codejenn.sh ${DEST}"
