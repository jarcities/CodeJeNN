## CodeJeNN Tutorials

These tutorials demonstrate the full CodeJeNN workflow: generating training
data for the viscosity neural network, verifying the network, running a
baseline splitter-plate CFD case, and then continuing that case with and
without the NN model active.

Assuming you followed the steps in the `readme.md` in the super directory of this directory and the OpenFOAM environment is active, the following layout is explained below:

## Directory Contents

```
tutorials/
    └── submit_splitter_1_2.sh          # SLURM submit script (step 5)
    └── H2_O2_N2_mu_data/               # Step 2 — generate training data
    └── H2_O2_N2_check_nn/              # Step 3 — verify NN implementation
    └── H2_O2_N2_splitter/              # Step 4 — run the splitter-plate case
    └── H2_O2_N2_splitter_developed/    # Pre-computed developed solution (t = 3.32×10⁻⁴ s)
```

All tutorials model a **H₂/air splitter-plate mixing layer** where air is
represented as an N₂/O₂ mixture (Y_N2 = 0.767, Y_O2 = 0.233).  The hydrogen
stream enters at 350 K (M = 0.3) and the air stream at 1500 K (M = 0.3).
Chemistry is disabled thus the case is non-reacting.

## Step 1: Generate NN Training Data

This step generates the CSV data used to train the mixture-viscosity neural
networks. The sampler draws from the physical mixing-line between a pure-H₂ fuel stream and an air oxidizer stream, blended with uniform Dirichlet sampling to broaden coverage. You will first `cd` into the `H2_O2_N2_mu_data/` directory then generate the data via:

```bash
cd H2_O2_N2_mu_data
generateData
```

The output should be `mu_training_data.csv` with 10,000 rows & columns with the following data -> `j, H2, O2, N2, T, mu`

Each row is one (composition, temperature) → mixture viscosity sample computed
from the same log-polynomial Wilke rule used by the solver.  The data is used
to train the viscosity NNs embedded in `model.hpp`.

If you wish to change some parameters in the training data, you may do so in `constant/generateDataProperties`. Below lists the sampling parameters to change.

| Parameter | Value | Meaning |
|---|---|---|
| `nSamples` | 10 000 | Total samples |
| `fracPhysical` | 0.4 | Fraction from the H₂/air mixing line |
| `T_fuel` | 350 K | Hydrogen stream temperature |
| `T_oxidizer` | 1500 K | Air stream temperature |
| `T_scatter` | ±200 K | Random scatter around the blended temperature |

## Step 2: Train an MLP

This step you will train an MLP based on the data created. Then `CodeJeNN` will be used to generate a C++ header file of that model.

```bash
./train.sh
```

After running this step, `model.hpp` will be created and ready for use.

## Step 3: Verify the Neural-Network Implementation

This step validates the CodeJeNN viscosity NN model against the
polynomial Wilke reference using 2,000 random samples drawn from the same
distribution as the training data. You are going to `cd` into `H2_O2_N2_check_nn/` then verify 

```bash
cd H2_O2_N2_check_nn
checkNNPrediction
```

Output should say `nn_check_results.csv` and a terminal summary reading:

```
Results written to 'nn_check_results.csv'
  NN | mean: X.XX %  max: X.XX %
```

A low mean error (< 1 %) confirms that the NN weights in
`model.hpp` are correctly embedded and that the
species ordering in the interface (`[Y_O2, Y_N2, Y_H2, T]`) matches what the
solver passes at runtime.

## Step 4: Run the Splitter-Plate Case

Within `H2_O2_N2_splitter/` is the baseline CFD case.  It runs the non-reacting H₂/air splitter-plate mixing layer for **five flow-through times** (t = 0 → 3.32×10⁻⁴ s, where one flow-through time is L/U_air = 0.015 m / 226 m/s ≈ 6.64×10⁻⁵ s).

**Mesh and initial field setup**:

```bash
cd H2_O2_N2_splitter
blockMesh
setFields
```

`blockMesh` generates the base structured mesh from `system blockMeshDict`. `setFields` applies the initial species and temperature conditions defined in `system/setFieldsDict`.

For a refined mesh (matching the developed solution in `H2_O2_N2_splitter_developed`), use the full preparation script instead:

```bash
./system/prepare_mesh_fields.sh
```

This runs blockMesh followed by three successive passes of topoSet + refineMesh
before calling setFields.

**Decompose and run**:

```bash
decomposePar
mpirun -n <nprocs> detonationFoam_V2.0 -parallel
```

Replace `<nprocs>` with the value of `numberOfSubdomains` in `system/decomposeParDict` (default: **128**). The solver writes one snapshot every flow-through time (`writeInterval 6.64e-5`).  The run ends at `endTime 3.32e-4`. The developed solution at t = 3.32×10⁻⁴ s is already provided in `H2_O2_N2_splitter_developed/0.000332/`.  You can skip step 4 and proceed directly to step 5 if you only want to run the continuation.