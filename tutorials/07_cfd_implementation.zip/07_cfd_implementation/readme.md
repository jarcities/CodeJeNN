## CFD Implementation Testcase

This directory contains the set of files needed to apply a CodeJeNN code generated model for transport modifications to a clean checkout of
[detonationFoam](https://github.com/JieSun-pku/detonationFoam).

Nothing here is a fork of detonationFoam. The files in `applications/` are
either drop-in replacements for existing detonationFoam source files or
entirely new files. There are two bash scripts used to automate applying and reversing those changes made to detonationFOAM.

## Directory Contents

```plaintext
07_cfd_implementation/
    └── generate_solvers.sh
    └── remove_codejenn.sh
    └── tutorials/                               # step-by-step tutorial cases
    └── paper_data/                              # minimal cases for VTK export
        └── nn_off/                              # splitter_1 — Wilke baseline
        └── nn_on/                              # splitter_2 — NNHI active
    └── applications/
        └── solvers/
            └── Allmake                              # top-level build script
            └── checkMuNNError/                      # [NEW] post-processing utility
                └── checkMuNNError.C
                └── Make/{files,options}
            └── checkNNPrediction/                   # [NEW] NN validation utility
                └── checkNNPrediction.C
                └── Make/{files,options}
            └── generateData/                        # [NEW] training data generator
                └── generateData.C
                └── Make/{files,options}
            └── detonationFoam_V2.0/
                └── Make/
                    └── options                      # [MODIFIED]
                └── detonationFoam_V2.0.C            # [MODIFIED]
                └── solverTypeNS_mixtureAverage/
                    └── solverTypeNS_mixtureAverage.H  # [MODIFIED]
                    └── rhoYEqn_NS_mixtureAverage.H    # [MODIFIED]
                    └── transport/
                        └── readChemistryProperties.H  # [MODIFIED]
                        └── createDiffFields.H         # [MODIFIED]
                        └── createMuFields.H           # [MODIFIED]
                        └── updateTransProperties.H    # [MODIFIED]
                        └── codeJeNN_diffusion.H       # [NEW] diffusion NN stub
                        └── nn_diffusion_interface.H   # [NEW] OpenFOAM↔NN bridge
                        └── nn_mu_interface.H          # [NEW] OpenFOAM↔NN bridge
                        └── model.hpp           # [NEW] viscosity NN
```

## Step 1: Installing `OpenFOAM-8`

There are 3 main steps you have to do

    1. Install OpenFOAM-8

    2. Set the environment variables

    3. Compile OpenFOAM-8

All instructions to conduct those three steps for OpenFOAM 8 can be found on the official website:

```
https://openfoam.org/download/8-source/
```

You may confirm that sourcing the environment works via:

```bash
source /path/to/OpenFOAM-8/etc/bashrc
foamVersion   # should print 8
```

Then you need to <mark>compile</mark> OpenFOAM via `./Allwmake` in `OpenFOAM-8/` which is also instructed in the official source website. This portion can take several hours.


## Step 2: Installing and Refractoring `detonationFOAM`

First you must clone [detonationFoam](https://github.com/JieSun-pku/detonationFoam), then refractor it by copying pre-written files found in `application/` which is already done with `generate_solvers.sh`.

```bash
./generate_solvers.sh          # clones detonationFoam and patches it
source /path/to/OpenFOAM-8/etc/bashrc
cd detonationFoam/applications/solvers
./Allmake                      # build everything
```

After a successful build, confirm with:

```bash
which generateData
which checkNNPrediction
which detonationFoam_V2.0
```

To undo all modifications and restore the clean clone of [detonationFoam](https://github.com/JieSun-pku/detonationFoam):

```bash
cd cfd_for_jay
./remove_codejenn.sh
```

Next you may carry on with the <mark>readme.md</mark> in `tutorials/` to reconduct the data and implementation presented in the paper that is cited with this repo.

***What do the modifications do?***

All changes are confined to the `NS_mixtureAverage` solver path. The Euler
and `NS_Sutherland` paths are completely untouched. Every NN flag defaults
to `false`, so the solver behaves identically to stock detonationFoam unless
you explicitly enable an NN model in `constant/chemistryProperties`.